//10. Reescreva o programa abaixo usando ponteiros, ajustando a declara��o do vetor atrav�s de aloca��o
//din�mica e os acessos ao vetor atrav�s da aritm�tica de ponteiros.
//DOUGLAS MONTOVONI BATISTA

#include <stdio.h>
#include<stdlib.h> 
#define MAXN 10

/*ANTES:
printf("\n---------------------------------\n");
int main(int argc, char *argv[]) { 
	int m[MAXN][MAXN];
	for(int i=0; i<MAXN; i++) {
	for(int j=0; j<MAXN; j++) {
	m[i][j] = 0;
 }
 }
	for(int i=0; i<MAXN; i++) {
	for(int j=0; j<MAXN; j++) {
	printf("%d ", m[i][j]);
 }
	printf("\n");
 }
	return 0;
}
printf("\n---------------------------------\n");*/


//Depois
int main() {
	int l, c, i, j;
	printf("Informe o numero de linhas: ");
	scanf("%d", &l);
	printf("Informe o numero de colunas: ");
	scanf("%d", &c);
	 
int **a;
a = (int**) malloc(l * sizeof(int *));
 
for (i = 0; i < l; ++i) {
	a[i] = (int*) malloc(c * sizeof(int));
}
 
	printf("Informe valores para cada posicao:\n");
 
for (i = 0; i < l; ++i) {
	for (j = 0; j < c; ++j) {
	printf("a[%d][%d] = ", i, j);
scanf("%d", &a[i][j]);
}
}
for (i = 0; i < l; ++i) {
	for (j = 0; j < c; ++j){
		printf("%d\t", a[i][j]);
}
	printf("\n");
} 
	for(i = 0; i < l; i++) {
	free(a[i]);
}
	free(a);
	return 0;
}
