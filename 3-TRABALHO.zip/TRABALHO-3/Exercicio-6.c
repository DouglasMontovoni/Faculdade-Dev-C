//6. Qual � o valor de count ap�s a execu��o do seguinte c�digo: 
//DOUGLAS MONTOVONI BAISTA

#include <stdio.h>
int main(int argc, char *argv[]) { 
	int x, *y, count;
	x=100;
	count=999;
	y= &x;
	count= *y;
	
	printf("/n %d /n",count);
	
	return 0;
}
