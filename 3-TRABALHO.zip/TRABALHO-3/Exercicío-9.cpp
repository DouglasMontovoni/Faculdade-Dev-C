//9. Verifique o programa abaixo. Encontre o seu erro e corrija-o para que escreva o n�mero 10 na tela.
//DOUGLAS MONTOVONI BATISTA

#include <stdio.h>
int main(int argc, char *argv[]) { 
	int x, *p, **q;
	p = &x;
	q = &p;
	x = 10;
	
	printf("\n %d \n", x);
	return 0;
}
