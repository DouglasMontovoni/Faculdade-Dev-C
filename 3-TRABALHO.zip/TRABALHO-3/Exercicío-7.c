//7. Escreva um procedimento em C com prot�tipo 
//void operacoes (int a, int b, int *soma, int *subtracao); 
//que receba dois n�meros inteiros e devolva a soma dos dois n�meros em *soma e a subtra��o em
//*subtracao. Crie o programa principal para testar a implementa��o. 
//DOUGLAS MONTOVONI BATISTA

#include <stdio.h>
#include <stdlib.h>

void operacoes (int x, int y, int *soma, int *subtracao){
	*soma = x + y;
	*subtracao = x - y;
}
int main(int argc, char *argv[]) {  

int x, y, soma, subtracao;

	printf("VALOR DE X ->  ");
	scanf("%d", &x);
	printf("VALOR DE Y ->  ");
	scanf("%d", &y);
    
operacoes(x, y, &soma, &subtracao);

	printf("\n");
	printf("SOMA = %d + %d = %i\n",x ,y, soma);
	printf("SUBTRACAO = %d - %d = %i\n",x ,y, subtracao);	
	
return 0;
}

