//8)Qual � o valor de *p e *q ap�s a execu��o do seguinte c�digo 
//DOUGLAS MONTOVONI BATISTA

#include <stdio.h>
	int main(int argc, char *argv[]) { 
	int a=3, b=2, *p = NULL, *q = NULL;
	p = &a;
	q = p;
	*q = *q +1;
	q = &b;
	b = b + 1;
	
	printf("\n VALOR DE *P -> %d \n" , *p);
	printf("\n VALOR DE *Q -> %d \n ", *q);
	
	return 0;
}
