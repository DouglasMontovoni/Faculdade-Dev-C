#include <stdio.h>
#include <string.h>
#include <locale.h>

/*Implemente um programa em C que leia o nome, a cidade e a quantidade de estudantes
de uma faculdade. Imprima o nome, a cidade e a quantidade de estudantes da faculdade.*/
//DOUGLAS MONTOVONI BATISTA

typedef struct {
	char Nome[30];
	char Cidade[30];
	int estudantes;
} TipoFaculdade;

int main(int argc, char *argv[]) {
	setlocale(LC_ALL, "Portuguese");   

	TipoFaculdade Faculdades;
	
	printf("NOME DA FACULDADE: ");
	gets(Faculdades.Nome);
	
	printf("CIDADE: ");
	scanf("%s", &Faculdades.Cidade);
	
	printf("QUANTIDADE DE ESTUDANTES? ");
	scanf("%d", &Faculdades.estudantes);
	
	printf("____________________________________________\n\n");

	printf("A FACULDADE %s, EST� LOCAlIZADA NA CIDADE DE %s, COM %d ESTUDANTES.. \n", Faculdades.Nome, Faculdades.Cidade, Faculdades.estudantes);
    return 0;
}
