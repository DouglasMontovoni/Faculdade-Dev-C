#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAXN 2000 

/*Utilizando o registro do item A, implemente um programa em C que leia o nome, a cidade
e a quantidade de estudantes de v�rias faculdades. Imprima o nome, a cidade e a
quantidade de estudantes de cada faculdade.*/
//DOUGLAS MONTOVONI BATISTA

typedef struct {
	char Nome[30];
	char Cidade[30];
	int Estudantes;
} TipoFaculdade;

typedef struct {
	TipoFaculdade Lista [MAXN];
} ListaDeFaculdades;

int main(int argc, char *argv[]) {  

	ListaDeFaculdades Faculdades;
	int i = 0, continuar;
	
	do {
		printf("NOME DA FACULDADE: ");	
		gets(Faculdades.Lista[i].Nome);
		 
		printf("CIDADE: ");	
		gets(Faculdades.Lista[i].Cidade);
	
		printf("QUANTIDADE DE ESTUDANTES: ");	
		scanf("%d", &Faculdades.Lista[i].Estudantes);
		getchar();
		
		printf("____________________________________\n\n");
	
		i++;
		if (i == MAXN)
			break;
		
		printf("DESEJA CONTINUAR? (1-SIM / 0-NAO): ");
		scanf("%d", &continuar);	
		getchar();
		
	}while (continuar);
	
	printf("LISTA DE FACULDADES\n");
	printf("%-4s %-15s %-10s %-10s\n", "#", "FACULDADE", "CIDADE", "ESTUDANTES");
	
	for(int k=0; k<i; k++) {
		printf("%-4d %-15s %-10s %d\n", k,Faculdades.Lista[k].Nome, Faculdades.Lista[k].Cidade, Faculdades.Lista[k].Estudantes);
	}
   return 0;
}
