#include <stdio.h>
#include <locale.h>
#include <string.h>
#define MAXN 200

/*Utilizando o registro do item B, implemente um programa em C que leia o nome do
Diretor e a respectiva Regi�o (Centro Oeste, Nordeste, etc) de um Grupo de Faculdades.
Imprima o nome do Diretor, UF a lista e de faculdades referente ao grupo.*/
//DOUGLAS MONTOVONI BATISTA

typedef struct {
	char Nome[30];
	char Cidade[30];
	int Estudantes;
} TipoFaculdade;

typedef struct {
	TipoFaculdade Lista [MAXN];
} ListaDeFaculdades;

typedef struct {
	char NomeDiretor[30];
	char Regiao[30];
	ListaDeFaculdades Grupo;
} GrupoDeFaculdades;

int main(int argc, char *argv[]) {
	setlocale(LC_ALL, "Portuguese");  

	ListaDeFaculdades Faculdades;
	GrupoDeFaculdades Grupo;
	int i = 0, continuar;
	
		printf("DIGITE O NOME DO DIRETOR: ");
		gets(Grupo.NomeDiretor);
		
		printf("DIGITE A REGI�O: ");
		gets(Grupo.Regiao);
	
	do {
		printf("NOME DA FACULDADE: ");	
		gets(Faculdades.Lista[i].Nome);
		 
		printf("CIDADE: ");	
		gets(Faculdades.Lista[i].Cidade);
	
		printf("QUANTIDADE DE ESTUDANTES: ");	
		scanf("%d", &Faculdades.Lista[i].Estudantes);
		getchar();
		
		printf("_________________________________________________________________________\n");
	
		i++;
		if (i == MAXN)
			break;
		
		printf("\nDESEJA CONTINUAR? (1-SIM / 0-NAO):");
		scanf("%d", &continuar);	
		getchar();
		
	}while (continuar);
	printf("------------------------------------------------------------------------\n");
	printf("NOME DO DIRETOR - %s / REGI�O - %s \n\n",Grupo.NomeDiretor,Grupo.Regiao);
	printf("------------------------------------------------------------------------\n");
	printf("LISTA DE FACULDADES\n");
	printf("%-4s %-20s %-20s %-10s\n", "#", "FACULDADE", "CIDADE", "ESTUDANTES");
	
	for(int k=0; k<i; k++) {
		printf("%-4d %-20s %-20s %d\n", k,Faculdades.Lista[k].Nome, Faculdades.Lista[k].Cidade, Faculdades.Lista[k].Estudantes);
	}
   return 0;
}
